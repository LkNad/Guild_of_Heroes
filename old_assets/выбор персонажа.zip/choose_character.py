import pygame
import sys

# Инициализация Pygame
pygame.init()

# Настройки экрана
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Цвета
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

font = pygame.font.Font("DreiFraktur.ttf", 36)

background_image_characters = pygame.image.load("fon_characters.jpg")
background_image_characters = pygame.transform.scale(background_image_characters, (WIDTH, HEIGHT))
background_image_characters_2 = pygame.image.load("fon_characters_2.jpg")
background_image_characters_2 = pygame.transform.scale(background_image_characters_2, (WIDTH, HEIGHT))

# Загружаем изображения гербов
emblem1_image = pygame.image.load("gerb_1.png")
emblem2_image = pygame.image.load("gerb_2.png")
emblem3_image = pygame.image.load("gerb_3.png")
# Для проверки на пересечение
emblem1_rect = emblem1_image.get_rect()
emblem1_rect.topleft = (72, 178)
emblem2_rect = emblem1_image.get_rect()
emblem2_rect.topleft = (304, 222)
emblem3_rect = emblem1_image.get_rect()
emblem3_rect.topleft = (550, 170)
# Загружаем изображения персонажей
character1_image = pygame.image.load("1_c.png")
# Для проверки на пересечение
character1_rect = character1_image.get_rect()
character1_rect.topleft = (72, 178)



def draw_emblems():
    screen.blit(background_image_characters, (0, 0))
    screen.blit(emblem1_image, emblem1_rect.topleft)
    screen.blit(emblem2_image, emblem2_rect.topleft)
    screen.blit(emblem3_image, emblem3_rect.topleft)

    font = pygame.font.Font("DreiFraktur.ttf", 27)
    text_surface_wars = font.render('Войны', True, WHITE)
    text_rect_wars = text_surface_wars.get_rect(topleft=(97, 424))
    text_surface_magicians = font.render('Волшебники', True, WHITE)
    text_rect_magicians = text_surface_magicians.get_rect(topleft=(302, 424))
    text_surface_fighters = font.render('Бойцы', True, WHITE)
    text_rect_fighters = text_surface_fighters.get_rect(topleft=(597, 424))

    screen.blit(text_surface_wars, text_rect_wars)
    screen.blit(text_surface_magicians, text_rect_magicians)
    screen.blit(text_surface_fighters, text_rect_fighters)


def show_wars_class():
    print('wars')
    pass


def show_magicians_class():
    print('magicians')
    screen.blit(background_image_characters_2, (0, 0))
    screen.blit(character1_image, character1_rect.topleft)




def show_fighters_class():
    print('fighters')
    pass


running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            if emblem1_rect.collidepoint(mouse_pos):
                show_wars_class()
            elif emblem2_rect.collidepoint(mouse_pos):
                show_magicians_class()
            elif emblem3_rect.collidepoint(mouse_pos):
                show_fighters_class()
            print(mouse_pos)

    # Очищаем экран
    screen.fill(BLACK)
    draw_emblems()
    # Обновляем экран
    pygame.display.flip()
pygame.quit()
sys.exit()
